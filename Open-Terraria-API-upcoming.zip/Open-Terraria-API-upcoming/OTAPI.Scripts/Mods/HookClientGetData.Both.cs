﻿/*
Copyright (C) 2020 DeathCradle

This file is part of Open Terraria API v3 (OTAPI)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/
#pragma warning disable CS8321 // Local function is declared but never used
#pragma warning disable CS0436 // Type conflicts with imported type

#if tModLoaderServer_V1_3 || tModLoader_V1_4
System.Console.WriteLine("Get data not available in TML");
#else
using ModFramework;
using Mono.Cecil.Cil;
using MonoMod;
using OTAPI;
using System;

/// <summary>
/// @doc A mod to create Hooks.MessageBuffer.GetData. Allows plugins to process received packet data.
/// </summary>
[Modification(ModType.PreMerge, "Hooking Terraria.MessageBuffer.GetData")]
[MonoMod.MonoModIgnore]
void HookClientGetData(MonoModder modder)
{
    int temp = 0;
    var GetData = modder.GetILCursor(() => (new Terraria.MessageBuffer()).GetData(0, 0, out temp));

    GetData.GotoNext(
        //if (b >= 140) { return; }
        i => i.OpCode == OpCodes.Ldloc_0
#if TerrariaServer_1448_OrAbove || Terraria_1448_OrAbove
        , i => i.OpCode == OpCodes.Ldsfld
#else
        , i => i.OpCode == OpCodes.Ldc_I4
#endif
        , i => i.OpCode == OpCodes.Blt_S
        , i => i.OpCode == OpCodes.Ret
    );
#if !TerrariaServer_1448_OrAbove && !Terraria_1448_OrAbove
    var maxPackets = (int)GetData.Instrs[GetData.Index + 1].Operand;
#endif

    GetData.RemoveRange(4);

    GetData.Emit(OpCodes.Ldarg_0);
    GetData.Emit(OpCodes.Ldloca, GetData.Body.Variables[0]); // packetID
    GetData.Emit(OpCodes.Ldloca, GetData.Body.Variables[1]); // readOffset

    foreach (var prm in GetData.Method.Parameters)
        GetData.Emit(prm.IsOut ? OpCodes.Ldarg : OpCodes.Ldarga, prm);

#if TerrariaServer_1448_OrAbove || Terraria_1448_OrAbove
    var fld = modder.GetFieldDefinition(() => Terraria.ID.MessageID.Count);
    GetData.Emit(OpCodes.Ldsfld, fld);
#else
    GetData.Emit(OpCodes.Ldc_I4, maxPackets);
#endif
    GetData.EmitDelegate(OTAPI.Hooks.MessageBuffer.InvokeGetData);
    GetData.Emit(OpCodes.Brtrue, GetData.Instrs[GetData.Index]);
    GetData.Emit(OpCodes.Ret);
}

namespace OTAPI
{
    public static partial class Hooks
    {
        public static partial class MessageBuffer
        {
            public class GetDataEventArgs : EventArgs
            {
                public HookResult? Result { get; set; }

                public Terraria.MessageBuffer Instance { get; set; }
                public byte PacketId { get; set; }
                public int ReadOffset { get; set; }
                public int Start { get; set; }
                public int Length { get; set; }
                public int MessageType { get; set; }
                public int MaxPackets { get; set; }
            }
            public static event EventHandler<GetDataEventArgs> GetData;

            public static bool InvokeGetData(global::Terraria.MessageBuffer instance, ref byte packetId, ref int readOffset, ref int start, ref int length, ref int messageType, int maxPackets)
            {
                var args = new GetDataEventArgs()
                {
                    Instance = instance,
                    PacketId = packetId,
                    ReadOffset = readOffset,
                    Start = start,
                    Length = length,
                    MessageType = messageType,
                    MaxPackets = maxPackets,
                };

                GetData?.Invoke(null, args);

                packetId = args.PacketId;
                readOffset = args.ReadOffset;
                start = args.Start;
                length = args.Length;
                messageType = args.MessageType;
                maxPackets = args.MaxPackets;

                return args.Result != HookResult.Cancel && packetId < maxPackets;
            }
        }
    }
}

#endif