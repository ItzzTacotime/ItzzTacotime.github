rm -rf OTAPI.Client.Launcher/bin
rm -rf OTAPI.Client.Launcher/obj

rm -rf OTAPI.Server.Launcher/bin
rm -rf OTAPI.Server.Launcher/obj

rm -rf OTAPI.Common/bin
rm -rf OTAPI.Common/obj

rm -rf OTAPI.Patcher/bin
rm -rf OTAPI.Patcher/obj

rm -rf OTAPI.Scripts/bin
rm -rf OTAPI.Scripts/obj

rm -rf examples/RuntimeExample.Client/bin
rm -rf examples/RuntimeExample.Client/obj

rm -rf examples/RuntimeExample.Server/bin
rm -rf examples/RuntimeExample.Server/obj

rm -rf FNA/bin
rm -rf FNA/obj
rm -rf FNA/obj_core
