#!/bin/bash
./bin/OTAPI.Client.Launcher